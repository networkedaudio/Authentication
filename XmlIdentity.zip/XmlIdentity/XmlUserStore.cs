﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlIdentity
{
    public class XmlUserStore : IUserStore<ApplicationUser>, IUserEmailStore<ApplicationUser>
    {

        public XmlUserStore() 
        {
            ApplicationUsers.IDs.Clear();
            ApplicationUser applicationUser = new ApplicationUser();
            applicationUser.Name = "Erik";
            applicationUser.Email = "erik.devane@clearcom.com";
            applicationUser.Id = Guid.NewGuid();
            ApplicationUsers.IDs.TryAdd(applicationUser.Id, applicationUser);
        }
        public Task<IdentityResult> CreateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<IdentityResult> DeleteAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
           // throw new NotImplementedException();
        }

        public Task<ApplicationUser?> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<ApplicationUser?> FindByIdAsync(string userId, CancellationToken cancellationToken)
        {
            Guid id = new Guid(userId);

            if(ApplicationUsers.IDs.TryGetValue(id, out ApplicationUser? applicationUser))
            {
                return Task.FromResult(applicationUser);
            }

            // not found
            return null;

        }

        public Task<ApplicationUser?> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
        {
            foreach (var currentIdentity in ApplicationUsers.IDs.Values) 
            {
                if (currentIdentity.Name.Equals(normalizedUserName, StringComparison.OrdinalIgnoreCase))
                {
                    ApplicationUser applicationUser = new ApplicationUser();
                    applicationUser.UserName = normalizedUserName;
                    applicationUser.Id = currentIdentity.Id;
                    return Task.FromResult(applicationUser);
                }
            }

            return null;
        }

        public Task<string?> GetEmailAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<bool> GetEmailConfirmedAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string?> GetNormalizedEmailAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string?> GetNormalizedUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetUserIdAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<string?> GetUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetEmailAsync(ApplicationUser user, string? email, CancellationToken cancellationToken)
        {
            // var foundUser = FindByIdAsync(user.Id.ToString(), cancellationToken).Result;
            user.Email = email;

            ApplicationUsers.IDs.AddOrUpdate(user.Id, user, (key, oldValue) => user);
          
            return Task.CompletedTask;
        }

        public Task SetEmailConfirmedAsync(ApplicationUser user, bool confirmed, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetNormalizedEmailAsync(ApplicationUser user, string? normalizedEmail, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetNormalizedUserNameAsync(ApplicationUser user, string? normalizedName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetUserNameAsync(ApplicationUser user, string? userName, CancellationToken cancellationToken)
        {
            user.UserName = userName;

            ApplicationUsers.IDs.AddOrUpdate(user.Id, user, (key, oldValue) => user);

            return Task.CompletedTask;
        }

        public Task<IdentityResult> UpdateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
