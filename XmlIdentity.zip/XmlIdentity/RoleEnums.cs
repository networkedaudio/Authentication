﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlIdentity
{
    public enum RoleTypes
    {
        SystemAdministrator,
        Administrator,
        User
    }
}
